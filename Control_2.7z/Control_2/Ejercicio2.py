#Nombre: Raúl Espinoza
#Profesor: Gabriel Díaz Calderón



def buscar(lista):
    contador= 0
    search= input("Nombre de la nota: ")
    for i in range(0,len(lista)):
        for n in lista[i]:
            contador+=1
            if search==n:
                print("Fecha: ", lista[contador+1])
                print("Descripción: ", lista[contador+2])
            

def agregarnota(lista):
    nombre= input("Ingrese el nombre de la nota: ")
    fecha= input("Ingrese la fecha: ")
    descripcion= input("Ingrese la descripción: ")
    lista.append([nombre, fecha, descripcion])
    return lista

def show_menu():
    print("#"*50)
    print("Escoja su opcion")
    print("1) Agregar nota.")
    print("2) Visualizar notas.")
    print("3) Buscar nota. ")

def main():
    lista= []
    while True:
        show_menu()
        opcion= int(input("Su opción: "))
        if opcion==1:
            lista= agregarnota(lista)
        elif opcion==2:
            print(lista)
        elif opcion==3:
            buscar(lista)

if __name__=='__main__':
    main()
