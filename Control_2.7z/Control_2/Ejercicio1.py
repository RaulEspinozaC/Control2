#Alumno: Raúl Espinoza
#Profesor: Gabriel Díaz Calderón


def validacion1(msg):
    precio= 0
    letras= ['a','b','c','d','e','f','g','h','i','j','k','m','n','l','o','p','q','r','s','t','u','v','w','x','y','z']
    for i in msg:
        for l in letras:
            if i==l:
                precio+= 10
            else:
                pass
    
    
    return precio

def validacion2(msg):
    precio2= 0
    numeros= ['0','1','2','3','4','5','6','7','8','9']
    for i in msg:
        for n in numeros:
            if i==n:
                precio2+=20
            else:
                pass
    return precio2
def validacion3(msg):
    precio3= 0
    letras= ['a','b','c','d','e','f','g','h','i','j','k','m','n','l','o','p','q','r','s','t','u','v','w','x','y','z']
    numeros= ['0','1','2','3','4','5','6','7','8','9']
    for i in msg:
        for l in letras:
            for n in numeros:
                if i!= l and i!=n and i!= ' ':
                    precio3+=30
    return precio3
    
def show_menu():
    print("#"*40)
    print("Calcular el valor de un mensaje.")
    print("Ingrese su mensaje: ")
    

def main():
    show_menu()
    msg= input("Msg: ")
    precio= validacion1(msg)
    precio2= validacion2(msg)
    print("El precio es de: ", precio+precio2)
    
    

if __name__=='__main__':
    main()
    
    
